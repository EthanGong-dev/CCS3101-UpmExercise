package Lab2;

class Salary {
    double hours, rate, salary;
	
	public Salary(double hours, double rate) {
		this.hours = hours;
		this.rate = rate;
	}
	
	public Salary() {
        this.hours = 0.0;
        this.rate = 0.0;
        this.salary = 0.0;
    }
	
	public double computeSalary() {
		salary = hours*rate;
		return salary;
	}
	
	public void printSalary() {
		computeSalary();
		System.out.printf("Your salary for this month is RM%1.2f", salary);
		System.out.println();
	}
}
