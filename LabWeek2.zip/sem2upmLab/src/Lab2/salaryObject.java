package Lab2;

import java.util.Scanner;


public class salaryObject {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Salary s1 = new Salary(45.0, 100);
		s1.printSalary();
		
		Salary s2 = new Salary();
		System.out.print("Hours: ");
		s2.hours = input.nextDouble();
		System.out.print("Rate: ");
		s2.rate = input.nextDouble();
		s2.printSalary();
	}
}
