package Lab2;

public class TestIdentification {

	public static void main(String[] args) {
		Identification I1 = new Identification("Arman", "armanarfan481@gmail.com", 'm');
		
		System.out.println("Name: " + I1.getName());
		System.out.println("Email:" + I1.getEmail());
		System.out.println("Gender: " + I1.getGender());
		
		I1.setEmail("armanhensem123@gmail.com");
        System.out.println("New Email: " + I1.getEmail());
        
        System.out.println("New Data: " + I1.toString());
	}

}
