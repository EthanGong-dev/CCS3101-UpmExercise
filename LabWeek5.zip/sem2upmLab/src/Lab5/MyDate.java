package Lab5;

public class MyDate {
	private int year;
    private int month;
    private int day;

  //Constructor
    public MyDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    @Override
    public String toString() {
        return day + "/" + month + "/" + year;
    }
}
