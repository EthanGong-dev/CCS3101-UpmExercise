package Lab5;

public class TestProgramQuestion2 {
	public static void main(String[] args) {
		
		//create object for the date
        MyDate hiredDate = new MyDate(2023, 1, 15);

        //create object
        Person p1 = new Person("Ali", "KL", "012", "ali@mail.com");
        Student s1 = new Student("Abu", "Selangor", "013", "abu@mail.com", "Junior");
        Employee e1 = new Employee("Siti", "Ipoh", "014", "siti@mail.com", "Blok A", 3000, hiredDate);
        Faculty f1 = new Faculty("Dr. Ray", "Penang", "015", "ray@mail.com", "Bilik 1", 7000, hiredDate, "9am-5pm", "Lecturer");
        Staff st1 = new Staff("Liza", "Melaka", "016", "liza@mail.com", "Kaunter", 2500, hiredDate, "Clerk");

        System.out.println(p1);
        System.out.println(s1);
        System.out.println(e1);
        System.out.println(f1);
        System.out.println(st1);
    }
}
