package Lab5;

public class WeekdaySubscriber extends NewspaperSubscriber {
	
	//Constructor
	 WeekdaySubscriber (String address) {
		super(address);
		setSubscriptionRate(3.50);
	}
	 
	 //Override
	 public String toString() {
			return "Service type: Weekday Subscriber" + "\nStreet Address: " + getStreetAddress() + "\nRate: " + getSubscriptionRate() + "\n";
	}
}
