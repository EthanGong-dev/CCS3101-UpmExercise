package Lab5;

public class Student extends Person {
	private String status;
	
	//Constructor
	public Student(String name, String address, String phoneNumber, String email, String status) {
        super(name, address, phoneNumber, email);
        this.status = status;
    }
	
	@Override
    public String toString() {
        return "Class: Student, Name: " + getName();
    }
}
