package Lab5;

public class NewspaperSubscriber {
	private String streetAddress;
    private double subscriptionRate;

  //Constructor
    public NewspaperSubscriber(String address) {
        this.streetAddress = address;;
    }

    // Getters & Setters
    public String getStreetAddress() {
    	return streetAddress; 
    
    }
    public void setStreetAddress(String address) { 
    	this.streetAddress = address; 
    }

    public double getSubscriptionRate() {
    	return subscriptionRate; 
    }
    
    public void setSubscriptionRate(double rate) {
    	this.subscriptionRate = rate; 
    }

    public boolean equals(Object obj) {
        if (obj instanceof NewspaperSubscriber) {
            NewspaperSubscriber other = (NewspaperSubscriber) obj;
            return this.streetAddress.equalsIgnoreCase(other.streetAddress);
        }
        return false;
    }

}
