package Lab5;

public class Employee extends Person {
	private String office;
    private double salary;
    private MyDate dateHired;

  //Constructor
    public Employee(String name, String address, String phoneNumber, String email, String office, double salary, MyDate dateHired) {
        super(name, address, phoneNumber, email);
        this.office = office;
        this.salary = salary;
        this.dateHired = dateHired;
    }
}
