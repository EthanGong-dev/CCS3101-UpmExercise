package Lab5;

public class WeekendSubscriber extends NewspaperSubscriber {
	
	//Constructor
	WeekendSubscriber (String address) {
		super(address);
		setSubscriptionRate(2.00);
	}
	
	@Override
	public String toString() {
		return "Service type: Weekend Subscriber" + "\nStreet Address: " + getStreetAddress() + "\nRate: " + getSubscriptionRate() + "\n";
	}
}
