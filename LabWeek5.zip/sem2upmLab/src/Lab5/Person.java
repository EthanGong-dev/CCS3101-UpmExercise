package Lab5;

public class Person {
	private String name, address, phoneNumber, emailAddress;
	
	//Constructor
	Person (String name, String address, String phoneNumber, String emailAddress) {
		this.name = name;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
	}
	
	//Getter method
	public String getName() {
		return name;
	}
	
	@Override
    public String toString() {
        return "Class: Person, Name: " + name;
    }
}
