package Lab5;

import java.util.Scanner;

public class Subscribers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter street address: ");
        String address = input.nextLine();
        
        System.out.println("Chooose your services:");
        System.out.println("1. Seven Day (RM4.50)");
        System.out.println("2. Weekday (RM3.50)");
        System.out.println("3. Weekend (RM2.00)");
        System.out.print("Your choices (1-3): ");
        int choice = input.nextInt();

        //create object
        NewspaperSubscriber Ns;

        if (choice == 1) {
        	Ns = new SevenDaySubscriber(address);
        } else if (choice == 2) {
        	Ns = new WeekdaySubscriber(address);
        } else if (choice == 3) {
        	Ns = new WeekendSubscriber(address);
        	
        } else {
            System.out.println("This choice is not available.");
            return;
        }
        
        //invoke method
        PrintDetails(Ns);
	}
	
	public static void PrintDetails(Object o) {
        if (o instanceof SevenDaySubscriber) {
            SevenDaySubscriber sds = (SevenDaySubscriber) o;
            System.out.println(sds.toString());
        } 
        else if (o instanceof WeekdaySubscriber) {
            WeekdaySubscriber wds = (WeekdaySubscriber) o;
            System.out.println(wds.toString());
        } 
        else if (o instanceof WeekendSubscriber) {
            WeekendSubscriber wes = (WeekendSubscriber) o;
            System.out.println(wes.toString());
        }
    }

}
