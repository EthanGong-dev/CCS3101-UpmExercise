package Lab5;

public class SevenDaySubscriber extends NewspaperSubscriber {
	
	//Constructor
	SevenDaySubscriber (String address) {
		super(address);
		setSubscriptionRate(4.50);
	}

	@Override
	public String toString() {
		return "Service type: 7 Days Subscriber" + "\nStreet Address: " + getStreetAddress() + "\nRate: " + getSubscriptionRate() + "\n";
	}
}
