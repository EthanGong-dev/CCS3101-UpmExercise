package Lab10;

import java.util.Scanner;

public class CreateLoans {
    public static void main(String[] args) {
    	
        Scanner input = new Scanner(System.in);
        Loan[] loans = new Loan[5]; // Array of 5 loans as required

        System.out.print("Enter the current prime interest rate (%): ");
        double primeRate = input.nextDouble();

        for (int i = 0; i < loans.length; i++) {
            System.out.println("\n--- Enter Details for Loan #" + (i + 1) + " ---");
            
            int type = 0;
            while (type != 1 && type != 2) {
                System.out.print("Enter loan type (1 for Business, 2 for Personal): ");
                type = input.nextInt();
            }

            System.out.print("Enter loan number: ");
            int loanNum = input.nextInt();
            input.nextLine(); // Clear the input buffer

            System.out.print("Enter customer's last name: ");
            String lastName = input.nextLine();

            System.out.print("Enter loan amount (Max $100,000): ");
            double amount = input.nextDouble();

            System.out.print("Enter loan term (1, 3, or 5 years): ");
            int term = input.nextInt();

            if (type == 1) {
                loans[i] = new BusinessLoan(loanNum, lastName, amount, term, primeRate);
            } else {
                loans[i] = new PersonalLoan(loanNum, lastName, amount, term, primeRate);
            }
        }

        System.out.println("\n===================================");
        System.out.println("        ALL CREATED LOANS          ");
        System.out.println("===================================");
        
        for (Loan loan : loans) {
            System.out.println(loan);
        }
        
        input.close();
    }
}