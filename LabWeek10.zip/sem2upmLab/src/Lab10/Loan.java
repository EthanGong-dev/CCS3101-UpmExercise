package Lab10;

public abstract class Loan {
	
	//public attribute
    final String COMPANY_NAME = "Sanchez Construction Loan Co.";
    final double MAX_LOAN_AMOUNT = 100000.00;
    final int SHORT_TERM = 1;
    final int MEDIUM_TERM = 3;
    final int LONG_TERM = 5;

    //private and protected attribute
    private int loanNumber;
    private String lastName;
    protected double loanAmount;
    protected double interestRate;
    private int term;

    //constructor
    public Loan(int loanNumber, String lastName, double loanAmount, int term) {
        this.loanNumber = loanNumber;
        this.lastName = lastName;

        if (loanAmount > MAX_LOAN_AMOUNT) {
            this.loanAmount = MAX_LOAN_AMOUNT;
        } else {
            this.loanAmount = loanAmount;
        }

        if (term != SHORT_TERM && term != MEDIUM_TERM && term != LONG_TERM) {
            this.term = SHORT_TERM;
        } else {
            this.term = term;
        }
    }

    //abstract class
    public abstract void setInterestRate (double primeRate);

    //calculation
    public double calculateTotalOwed() {
        return loanAmount + (loanAmount * (interestRate / 100) * term);
    }

    @Override
    public String toString() {
        return String.format(
        		"Company Name: %s\nLoan Number: %d\nLast Name: %s\nLoan Amount: $%.2f\nInterest Rate: %.2f%%\nTerm: %d year(s)\nTotal Amount Owed: $%.2f\n-----------------------------------",
            COMPANY_NAME, loanNumber, lastName, loanAmount, interestRate, term, calculateTotalOwed()
        );
    }
}

