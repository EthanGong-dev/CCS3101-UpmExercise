package Lab10;

public class PersonalLoan extends Loan {
    public PersonalLoan(int loanNumber, String lastName, double loanAmount, int term, double primeRate) {
        super(loanNumber, lastName, loanAmount, term);
        setInterestRate(primeRate);
    }

    @Override
    public void setInterestRate(double primeRate) {
        this.interestRate = primeRate + 2.0;
    }
}

