package Lab10;

public class BusinessLoan extends Loan {
    public BusinessLoan(int loanNumber, String lastName, double loanAmount, int term, double primeRate) {
        super(loanNumber, lastName, loanAmount, term);
        setInterestRate(primeRate);
    }

    @Override
    public void setInterestRate(double primeRate) {
        this.interestRate = primeRate + 1.0; 
    }
}
