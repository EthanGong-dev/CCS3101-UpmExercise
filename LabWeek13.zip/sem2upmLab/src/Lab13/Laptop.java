package Lab13;

public class Laptop {
    private String brand;
    private double price;

    // Constructor
    public Laptop(String brand, double price) {
        this.brand = brand;
        this.price = price;
    }

    // Overridden toString method
    @Override
    public String toString() {
        return "Laptop [Brand=" + brand + ", Price=RM" + price + "]";
    }
}

