package Lab13;

import java.util.Scanner;

public class InventoryTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create inventory for laptops
        Inventory<Laptop> laptopInventory = new Inventory<>();
        System.out.println("Enter details for 3 Laptops:");
        for (int i = 1; i <= 3; i++) {
            System.out.print("Enter brand for Laptop " + i + ": ");
            String brand = scanner.nextLine();
            System.out.print("Enter price for Laptop " + i + ": ");
            double price = scanner.nextDouble();
            scanner.nextLine(); // Clear the buffer
            laptopInventory.addItem(new Laptop(brand, price));
        }

        // Create inventory for smartphones
        Inventory<Smartphone> smartphoneInventory = new Inventory<>();
        System.out.println("\nEnter details for 3 Smartphones:");
        for (int i = 1; i <= 3; i++) {
            System.out.print("Enter model for Smartphone " + i + ": ");
            String model = scanner.nextLine();
            System.out.print("Enter price for Smartphone " + i + ": ");
            double price = scanner.nextDouble();
            scanner.nextLine(); // Clear the buffer
            smartphoneInventory.addItem(new Smartphone(model, price));
        }

        // Display results using printInventory() utility
        System.out.println("\nLaptop Inventory");
        System.out.println("----------------");
        InventoryUtils.printInventory(laptopInventory);

        System.out.println("\nSmartphone Inventory");
        System.out.println("--------------------");
        InventoryUtils.printInventory(smartphoneInventory);

        scanner.close();
    }
}
