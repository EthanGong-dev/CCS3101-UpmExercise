package Lab13;

import java.util.ArrayList;

public class Inventory<T> {
    private ArrayList<T> items;

    // Constructor
    public Inventory() {
        this.items = new ArrayList<>();
    }

    // Method to add item
    public void addItem(T item) {
        items.add(item);
    }

    // Method to remove item
    public void removeItem(T item) {
        items.remove(item);
    }

    // Method to display all items
    public void displayItems() {
        for (T item : items) {
            System.out.println(item);
        }
    }
}

