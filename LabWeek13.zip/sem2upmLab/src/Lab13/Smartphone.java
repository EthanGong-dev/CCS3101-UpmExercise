package Lab13;

public class Smartphone {
    private String model;
    private double price;

    // Constructor
    public Smartphone(String model, double price) {
        this.model = model;
        this.price = price;
    }

    // Overridden toString method
    @Override
    public String toString() {
        return "Smartphone [Model=" + model + ", Price=RM" + price + "]";
    }
}

