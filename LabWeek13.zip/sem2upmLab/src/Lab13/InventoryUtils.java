package Lab13;

public class InventoryUtils {
    // Generic method accepting Inventory object of any type
    public static <T> void printInventory(Inventory<T> inventory) {
        inventory.displayItems();
    }
}

