package Lab7;

import java.util.Scanner;

public class payrollTest {

	public static void main(String[] args) {
		
        Scanner input = new Scanner(System.in);
        
        
        //try and catch block
        try {
            System.out.print("Enter workers name: ");
            String name = input.nextLine();
            
            System.out.print("Enter worker ID: ");
            int id = input.nextInt();
            
            Payroll worker = new Payroll(name, id);
            
            System.out.print("Enter hour pay rate: ");
            worker.setHourlyPayRate(input.nextDouble());
            
            System.out.print("Enter total work: ");
            worker.setNumHoursWorked(input.nextDouble());
            
            System.out.printf("Total pay: RM%.2f\n", worker.getGrossPay());

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
