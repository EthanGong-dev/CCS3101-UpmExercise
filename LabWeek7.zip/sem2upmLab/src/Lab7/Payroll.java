package Lab7;

public class Payroll {
	
	//private attributes
	private String name;
    private int idNumber;
    private double hourlyPayRate;
    private double numHoursWorked;

    //constructor
    public Payroll(String name, int id) throws EmptyNameException, InvalidIDException {
        setName(name);
        setIdNumber(id);
    }

    //set and get method
    public void setName(String name) throws EmptyNameException {
        if (name == null || name.trim().isEmpty()) {
        	throw new EmptyNameException();
        }
        this.name = name;
    }

    public void setIdNumber(int id) throws InvalidIDException {
        if (id <= 0) {
        	throw new InvalidIDException();
        }
        this.idNumber = id;
    }

    public void setHourlyPayRate(double rate) throws InvalidPayRateException {
        if (rate < 0 || rate > 25) {
        	throw new InvalidPayRateException();
        }
        this.hourlyPayRate = rate;
    }

    public void setNumHoursWorked(double hours) throws InvalidHoursException {
        if (hours < 0 || hours > 84) {
        	throw new InvalidHoursException();
        }
        this.numHoursWorked = hours;
    }

    public double getGrossPay() {
        return numHoursWorked * hourlyPayRate;
    }
}
