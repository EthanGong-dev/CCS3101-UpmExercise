package Lab7;

import java.util.Scanner;
import java.util.InputMismatchException;

public class monthDaysDemo {
    public static void main(String[] args) {
    	
    	//initialize
        String[] months = {"January", "February", "March", "April", "May", "June", 
                           "July", "August", "September", "October", "November", "December"};
        
        int[] dom = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        
        Scanner input = new Scanner(System.in);
        
        //try and catch block
        try {
            System.out.print("Enter an integer between 1 and 12: ");
            int choice = input.nextInt();
            
            System.out.println("Month: " + months[choice - 1] + ", Days: " + dom[choice - 1]);
            
        } catch (ArrayIndexOutOfBoundsException e) {
        	//if input is not 1 until 12
            System.out.println("Wrong number");
        } 
        catch (InputMismatchException e) {
        	//if input is not integer
            System.out.println("Error: Invalid input. Please enter an integer.");
        } 
        finally {
            input.close();
        }
    }
}
