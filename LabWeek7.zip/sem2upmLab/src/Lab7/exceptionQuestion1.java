package Lab7;

class EmptyNameException extends Exception {
    public EmptyNameException() {
    	super("Error: Employee name cannot be empty."); 
    }
}

class InvalidIDException extends Exception {
    public InvalidIDException() {
    	super("Error: Employee ID must be greater than 0.");
    }
}

class InvalidHoursException extends Exception {
    public InvalidHoursException() {
    	super("Error: Hours worked must be between 0 and 84.");
    }
}

class InvalidPayRateException extends Exception {
    public InvalidPayRateException() { 
    	super("Error: Hourly pay rate must be between 0 and 25.");
    }
}
