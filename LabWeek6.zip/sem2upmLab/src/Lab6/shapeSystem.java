package Lab6;

import java.util.ArrayList;
import java.util.Scanner;

public class shapeSystem {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        ArrayList<shape> shapeList = new ArrayList<>();

        // Input for 2D
        System.out.print("Enter Circle radius: ");
        shapeList.add(new circle(input.nextDouble()));

        System.out.print("Enter Triangle base & height: ");
        shapeList.add(new triangle(input.nextDouble(), input.nextDouble()));

        System.out.print("Enter Square side: ");
        shapeList.add(new square(input.nextDouble()));

        // Input for 3D
        System.out.print("Enter Cube side: ");
        shapeList.add(new cube(input.nextDouble()));

        System.out.print("Enter Sphere radius: ");
        shapeList.add(new sphere(input.nextDouble()));

        // Display results using Polymorphism
        System.out.println("\n--- List of Shapes and Calculations ---");
        for (shape s : shapeList) {
            System.out.println(s.toString());
        }
        
        input.close();
	}

}
