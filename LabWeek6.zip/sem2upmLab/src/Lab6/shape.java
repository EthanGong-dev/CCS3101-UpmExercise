package Lab6;

public class shape {
	public double calArea() {
		return 0;
	}
}
