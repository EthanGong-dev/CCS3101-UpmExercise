package Lab6;

public class square extends twoDimensional {
	private double side;
	
    public square(double s) {
    	this.side = s; 
    }
    
    @Override
    public double calArea() {
    	return side * side; 
    }
    
    @Override
    public String toString() {
    	return "Square Area: " + String.format("%.2f", calArea());
    }
}
