package Lab6;

public class circle extends twoDimensional {
	private double radius;
	
    public circle(double r) {
    	this.radius = r; 
    }
    
    @Override
    public double calArea() {
    	return Math.PI * radius * radius;
    }
    
    @Override
    public String toString() { return "Circle Area: " + String.format("%.2f", calArea()); }
}
