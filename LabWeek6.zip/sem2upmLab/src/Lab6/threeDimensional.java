package Lab6;

public class threeDimensional extends shape {
	public double calVolume() {
		return 0;
	}
}
