package Lab6;

public class Action extends Movie {
	
	public Action(int id, String title, String rating) {
		super(id, title, rating);
	}
	
    @Override
    public double calcLateFees(int daysLate) {
    	return daysLate * 8.0; 
    }
}
