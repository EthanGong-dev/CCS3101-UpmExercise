package Lab6;

public class Movie {
	private String rating;
    private int idNumber;
    private String movieTitle;

    public Movie(int idNumber, String movieTitle, String rating) {
        this.idNumber = idNumber;
        this.movieTitle = movieTitle;
        this.rating = rating;
    }
    
 // Accessors and Mutators
    public int getIdNumber() {
    	return idNumber; 
    }
    
    public void setIdNumber(int idNumber) {
    	this.idNumber = idNumber; 
    }
    public String getMovieTitle() {
    	return movieTitle; 
    }
    
    public void setMovieTitle(String movieTitle) {
    	this.movieTitle = movieTitle; 
    }
    
    public String getRating() { 
    	return rating; 
    }
    
    public void setRating(String rating) {
    	this.rating = rating; 
    }

    @Override
    public boolean equals(Object obj) {
        Movie movie = (Movie) obj;
        return idNumber == movie.idNumber;
    }
    
    public double calcLateFees(int daysLate) {
        return daysLate * 10.0;
    }
}
