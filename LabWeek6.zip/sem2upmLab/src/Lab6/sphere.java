package Lab6;

public class sphere extends threeDimensional {
	private double radius;
	
    public sphere(double r) {
    	this.radius = r; 
    }
    
    @Override   
    public double calArea() {
    	return 4 * Math.PI * Math.pow(radius, 2); 
    }
    
    @Override
    public double calVolume() {
    	return (4.0/3.0) * Math.PI * Math.pow(radius, 3);
    }
    
    @Override
    public String toString() { 
        return "Sphere Surface Area: " + String.format("%.2f", calArea()) + ", Volume: " + String.format("%.2f", calVolume()); 
    }
}
