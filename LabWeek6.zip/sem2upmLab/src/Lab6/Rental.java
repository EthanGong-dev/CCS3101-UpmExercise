package Lab6;

public class Rental {
	private Movie movie;
    private int customerId;
    private int daysLate;

    public Rental(Movie movie, int customerId, int daysLate) {
        this.movie = movie;
        this.customerId = customerId;
        this.daysLate = daysLate;
    }

    public double getLateFee() {
        return movie.calcLateFees(daysLate);
    }
}
