package Lab6;

public class triangle extends twoDimensional {
	private double base, height;
	
    public triangle(double b, double h) {
    	this.base = b; this.height = h;
    }
    
    @Override
    public double calArea() {
    	return 0.5 * base * height;
    }
    
    @Override
    public String toString() {
    	return "Triangle Area: " + String.format("%.2f", calArea());
    }
}
