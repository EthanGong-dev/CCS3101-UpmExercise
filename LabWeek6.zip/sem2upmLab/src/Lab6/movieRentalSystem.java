package Lab6;

import java.util.Scanner;

public class movieRentalSystem {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Rental[] rentals = new Rental[3];

        for (int i = 0; i < 3; i++) {
            System.out.println("\nEnter details for Movie " + (i + 1));
            System.out.print("Type (1: Action, 2: Comedy, 3: Drama): ");
            int type = sc.nextInt();
            System.out.print("ID Number: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Movie Title: ");
            String title = sc.nextLine();
            System.out.print("Rating (U/P13/18): ");
            String rating = sc.nextLine();
            System.out.print("Customer ID: ");
            int custId = sc.nextInt();
            System.out.print("Days Late: ");
            int days = sc.nextInt();

            Movie movie;
            if (type == 1) {
            	movie = new Action(id, title, rating);
            }
            else if (type == 2) {
            	movie = new Comedy(id, title, rating);
            }
            else {
            	movie = new Drama(id, title, rating);
            }

            rentals[i] = new Rental(movie, custId, days);
        }

        System.out.printf("\nTotal Late Fees Owed: RM%1.2f", lateFeesOwed(rentals));
	}
	
	 public static double lateFeesOwed(Rental[] rentals) {
	        double total = 0;
	        for (Rental r : rentals) {
	            total += r.getLateFee();
	        }
	        return total;
	    }

}
