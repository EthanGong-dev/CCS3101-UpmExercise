package Lab6;

public class cube extends threeDimensional {
	private double side;
	
    public cube(double s) {
    	this.side = s; 
    }
    
    @Override
    public double calArea() {
    	return 6 * Math.pow(side, 2); 
    }
    
    @Override
    public double calVolume() {
    	return Math.pow(side, 3); 
    }
    
    @Override
    public String toString() { 
        return "Cube Surface Area: " + String.format("%.2f", calArea()) + ", Volume: " + String.format("%.2f", calVolume()); 
    }
}
