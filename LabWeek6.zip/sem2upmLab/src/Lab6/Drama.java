package Lab6;

public class Drama extends Movie {
	
	public Drama(int id, String title, String rating) {
		super(id, title, rating); 
	}
	
    @Override
    public double calcLateFees(int daysLate) {
    	return daysLate * 4.0; 
    }
}
