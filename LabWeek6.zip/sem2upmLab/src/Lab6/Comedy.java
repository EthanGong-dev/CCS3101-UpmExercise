package Lab6;

public class Comedy extends Movie {
	
	public Comedy(int id, String title, String rating) {
		super(id, title, rating); 
	}
	
    @Override
    public double calcLateFees(int daysLate) {
    	return daysLate * 6.0; 
    }
}
