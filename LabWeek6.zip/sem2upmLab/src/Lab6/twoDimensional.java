package Lab6;

public class twoDimensional extends shape {

}
