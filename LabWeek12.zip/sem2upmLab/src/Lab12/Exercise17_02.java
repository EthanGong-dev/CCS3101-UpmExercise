package Lab12;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

public class Exercise17_02 {
    public static void main(String[] args) {
    	
        String fileName = "Exercise17_02.dat";
        
        try (DataOutputStream output = new DataOutputStream(new FileOutputStream(fileName, true))) {
            Random random = new Random();
            
            // Write 150 randomly generated integers using binary I/O
            for (int i = 0; i < 150; i++) {
                int randomInt = random.nextInt(1000); // Generates integers from 0 to 999
                output.writeInt(randomInt);
            }
            
            System.out.println("Successfully wrote 150 random integers to " + fileName);
            
        } catch (IOException e) {
            System.err.println("An I/O error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
