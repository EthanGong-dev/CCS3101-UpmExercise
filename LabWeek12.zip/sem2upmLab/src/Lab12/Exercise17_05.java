package Lab12;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.Date;

public class Exercise17_05 {
    public static void main(String[] args) {
        String fileName = "Exercise17_05.dat";

        int[] intArray = {1, 2, 3, 4, 5, 6};
        Date currentDate = new Date();
        double doubleValue = 10.5;

        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(fileName))) {
            
            output.writeObject(intArray);    
            output.writeObject(currentDate);  
            output.writeDouble(doubleValue);  
            
            System.out.println("Data berjaya disimpan ke dalam fail: " + fileName);
            System.out.println("Objek Tarikh disimpan: " + currentDate);
            
        } catch (IOException e) {
            System.err.println("Ralat I/O berlaku semasa menulis fail: " + e.getMessage());
        }
    }
}

