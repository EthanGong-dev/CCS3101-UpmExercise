package Lab12;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CreateTestData17_03 {
    public static void main(String[] args) {
        String fileName = "Exercise17_03.dat";
        
        // Sampel data nombor perpuluhan yang mahu dimasukkan
        double[] sampleNumbers = {10.5, 20.3, 5.75, 12.0, 51.45};
        
        try (DataOutputStream output = new DataOutputStream(new FileOutputStream(fileName))) {
            for (double num : sampleNumbers) {
                output.writeDouble(num);
            }
            System.out.println("Fail '" + fileName + "' berjaya dicipta dengan 5 sampel nombor!");
            System.out.println("Jumlah sepatutnya (Expected Sum): 100.00");
            
        } catch (IOException e) {
            System.err.println("Ralat mencipta fail: " + e.getMessage());
        }
    }
}

