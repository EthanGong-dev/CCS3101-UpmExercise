package Lab12;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Exercise17_03 {
    public static void main(String[] args) {

        String fileName = "Exercise17_03.dat";
        
        double totalSum = 0;
        int count = 0;


        try (DataInputStream input = new DataInputStream(new FileInputStream(fileName))) {

            while (true) {
                double value = input.readDouble();
                totalSum += value;
                count++;
            }
            
        } catch (FileNotFoundException e) {
            System.err.println("Ralat: Fail '" + fileName + "' tidak dijumpai.");
            System.err.println("Sila pastikan fail tersebut wujud di dalam direktori projek Eclipse anda.");
        } catch (EOFException e) {
            System.out.println("Selesai membaca keseluruhan fail.");
            System.out.println("Jumlah nombor dikesan: " + count);
            System.out.printf("Jumlah hasil tambah (Sum): %.2f\n", totalSum);
        } catch (IOException e) {
            System.err.println("Ralat I/O berlaku: " + e.getMessage());
        }
    }
}
