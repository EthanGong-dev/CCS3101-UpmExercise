package Lab12;

import java.io.*;

public class Exercise17_04 {
    public static void main(String[] args) {

        if (args.length != 2) {
            System.out.println("Cara penggunaan: java Exercise17_04 SourceTextFile TargetBinaryFile");
            System.exit(1);
        }

        File sourceFile = new File(args[0]);
        File targetFile = new File(args[1]);

        if (!sourceFile.exists()) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(sourceFile))) {
                writer.println("public class Welcome {");
                writer.println("    // Ini adalah fail sampel otomatik.");
                writer.println("}");
                System.out.println("Nota: Fail '" + args[0] + "' tidak dijumpai, sistem telah menciptanya secara automatik.");
            } catch (IOException e) {
                System.err.println("Gagal mencipta fail sumber automatik: " + e.getMessage());
                System.exit(2);
            }
        }

        try (
            BufferedReader input = new BufferedReader(new FileReader(sourceFile));
            DataOutputStream output = new DataOutputStream(new FileOutputStream(targetFile))
        ) {
            String line;
            while ((line = input.readLine()) != null) {
                output.writeUTF(line);
            }
            System.out.println("Saiz fail teks (" + sourceFile.getName() + "): " + sourceFile.length() + " bytes");
            System.out.println("Saiz fail binari (" + targetFile.getName() + "): " + targetFile.length() + " bytes");

        } catch (IOException e) {
            System.err.println("Ralat I/O berlaku: " + e.getMessage());
        }
    }
}


