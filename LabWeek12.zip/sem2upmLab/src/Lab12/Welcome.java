package Lab12;

public class Welcome {
    // Ini adalah contoh teks untuk ditukarkan ke UTF
}
