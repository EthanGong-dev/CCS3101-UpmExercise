package Lab9;

public class MainClassBank {
    public static void main(String[] args) {
        System.out.println("=== Bank Account Transaction System ===\n");

        bankAccount acc1 = new SavingsAccount("J23455", 100.00);
        System.out.println("Initial State -> " + acc1.toString());
        System.out.println("------------------------------------------------");

        // try withdrawal rm20
        System.out.println("[Executing Withdrawal of RM20.00]");
        boolean result = acc1.withdraw(20.00);
        System.out.println("Current State -> " + acc1.toString());
        System.out.println("------------------------------------------------");

        // try deposit rm20
        System.out.println("[Executing Deposit of RM20.00]");
        acc1.deposit(20.00);
        System.out.println("Current State -> " + acc1.toString());
        System.out.println("------------------------------------------------");

        // extra test
        System.out.println("[Testing Insufficient Balance: Withdraw RM100.00]");
        acc1.withdraw(100.00);
        System.out.println("Final State   -> " + acc1.toString());
        System.out.println("------------------------------------------------");
    }
}

