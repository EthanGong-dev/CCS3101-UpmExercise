package Lab9;

import java.util.Scanner;

public class mainClassGeometric {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input for square
        System.out.println("--- Input for Square ---");
        System.out.print("Enter height: ");
        double sqHeight = input.nextDouble();
        System.out.print("Enter width: ");
        double sqWidth = input.nextDouble();
        square square = new square("My Square", sqHeight, sqWidth);

        // Input for Triangle
        System.out.println("\n--- Input for Triangle ---");
        System.out.print("Enter height: ");
        double triHeight = input.nextDouble();
        System.out.print("Enter width: ");
        double triWidth = input.nextDouble();
        triangle triangle = new triangle("My Triangle", triHeight, triWidth);

        // Output result
        System.out.println("\n================ OUTPUT ================");
        
        System.out.println(square.toString());
        System.out.println("Type of Object: square");
        System.out.println("Number of Sides: " + square.getSides());
        
        System.out.println("----------------------------------------");
        
        System.out.println(triangle.toString());
        System.out.println("Type of Object: triangle");
        System.out.println("Number of Sides: " + triangle.getSides());
        
        System.out.println("----------------------------------------");

        if (geometricFigure.equalArea(square, triangle)) {
            System.out.println("Comparison Result: Both objects have the SAME area.");
        } else {
            System.out.println("Comparison Result: Both objects have DIFFERENT areas.");
        }
        System.out.println("========================================");
        
        input.close();
    }
}