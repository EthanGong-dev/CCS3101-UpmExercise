package Lab9;

public class triangle extends geometricFigure {
    private double height;
    private double width;
    private final int sides = 3; 

    public triangle(String objectName, double height, double width) {
        super(objectName);
        this.height = height;
        this.width = width;
    }

    @Override
    public double findArea() {
        return 0.5 * height * width;
    }

    public int getSides() {
        return sides;
    }
}