package Lab9;

public abstract class geometricFigure {
    private String objectName;

    public geometricFigure(String objectName) {
        this.objectName = objectName;
    }

    public String getObjectName() {
        return objectName;
    }

    //abstract method
    public abstract double findArea();

    public static boolean equalArea(geometricFigure fig1, geometricFigure fig2) {
        return fig1.findArea() == fig2.findArea();
    }

    @Override
    public String toString() {
        return "Object Name: " + objectName + "\nArea: " + findArea();
    }
}