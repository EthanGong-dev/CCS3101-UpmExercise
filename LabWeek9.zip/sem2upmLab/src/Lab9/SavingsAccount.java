package Lab9;

public class SavingsAccount extends bankAccount {
    private final double MIN_BALANCE = 10.00;
    private final double FEE = 2.00;

    //constructor
    public SavingsAccount(String id, double initialDeposit) {
        super(id, initialDeposit);
    }

    @Override
    public boolean withdraw(double amount) {
        double totalDeduction = amount + FEE;

        if ((balance - totalDeduction) < MIN_BALANCE) {
            System.out.println("Transaction Failed: Account balance is insufficient (Must maintain RM10 after fee).");
            return false;
        } else {
            balance -= totalDeduction;
            System.out.printf("Successfully withdrew RM%.2f (Fee: RM2.00)", amount);
            System.out.println();
            return true;
        }
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.printf("Successfully deposited RM%.2f", amount);
            System.out.println();
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }
}

