package Lab9;

public class square extends geometricFigure {
    private double height;
    private double width;
    private final int sides = 4;

    public square(String objectName, double height, double width) {
        super(objectName);
        this.height = height;
        this.width = width;
    }

    @Override
    public double findArea() {
        return height * width;
    }

    public int getSides() {
        return sides;
    }
}
