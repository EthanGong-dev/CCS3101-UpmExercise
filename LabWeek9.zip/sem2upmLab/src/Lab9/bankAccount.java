package Lab9;

public abstract class bankAccount {
    protected String customerId;
    protected double balance;

    //constructor
    public bankAccount(String customerId, double balance) {
        this.customerId = customerId;
        this.balance = balance;
    }

    //get Method
    public String getCustomerId() {
        return customerId;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + " | Balance: RM" + String.format("%.2f", balance);
    }

    //abstract method
    public abstract boolean withdraw(double amount);
    public abstract void deposit(double amount);
}
