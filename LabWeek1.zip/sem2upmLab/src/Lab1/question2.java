package Lab1;

class Stock {
	String symbol, name;
	double previousClosingPrice, currentPrice;
	
	Stock (String symbol, String name) {
		this.symbol = symbol;
		this.name = name;
	}
	
	public double getChangePercent() {
		return ((currentPrice - previousClosingPrice) / previousClosingPrice) * 100.0;
	}
}

public class question2 {

	public static void main(String[] args) {
		Stock s1 = new Stock("ORCL", "Oracle Corporation");
		
		s1.previousClosingPrice = 34.5;
		s1.currentPrice = 34.35;

        System.out.println("Stock Name    : " + s1.name);
        System.out.println("Stock Symbol  : " + s1.symbol);
        System.out.printf("Price Change  : %.2f%%\n", s1.getChangePercent());
	}

}
