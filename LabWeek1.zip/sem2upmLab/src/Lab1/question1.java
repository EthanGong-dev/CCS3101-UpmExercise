package Lab1;

class Rectangle {
	double width = 1, height = 1;
	
	Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}
	
	public double getArea() {
		return (width*height);
	}
	
	public double getPerimeter() {
		return 2*(width+height);
	}
}

public class question1 {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(4, 40);
		Rectangle r2 = new Rectangle(3.5, 35.9);
		
		System.out.printf("Rectangle 1\nWidth: %s\nHeight: %s\nArea: %.2f\nPerimeter: %s", r1.width, r1.height, r1.getArea(), r1.getPerimeter());
		System.out.println();
		System.out.println();
		System.out.printf("Rectangle 2\nWidth: %s\nHeight: %s\nArea: %.2f\nPerimeter: %s", r2.width, r2.height, r2.getArea(), r2.getPerimeter());
	}

}
