package Lab8;

import java.io.*;
import java.util.Scanner;

public class babyNamesRanking {
    public static void main(String[] args) {

    	//initialize file name
        String fname = "babyRanking"; 
        
        //input random name
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the name: ");
        String targetName = input.nextLine().trim();

        //if our input is null
        if (targetName.isEmpty()) {
            System.out.println("Error: Name cannot be empty.");
            input.close();
            return;
        }

        boolean found = false;

        //search a similar name as input
        try (BufferedReader reader = new BufferedReader(new FileReader(fname))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");
                if (parts.length >= 5) {
                    String rank = parts[0];
                    String boyName = parts[1];
                    String girlName = parts[3];

                    if (boyName.equalsIgnoreCase(targetName) || girlName.equalsIgnoreCase(targetName)) {
                        System.out.println(targetName + " is ranked no. " + rank);
                        found = true;
                        break;
                    }
                }
            }

            if (!found) {
                System.out.println("The name " + targetName + " is not listed in the ranking.");
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error: Fail '" + fname + "' is not found. Please refer to the right file name.");
        } catch (IOException e) {
            System.out.println("Error: Problem happen when open file: " + e.getMessage());
        } finally {
            input.close(); 
        }
    }
}