package Lab8;

import java.io.*;

public class UPMGradeCalculator {
	
	public static void main(String[] args) {
		
		//initialize both file name
		String fiName = "student_scores.txt";
		String foName = "student_grades.txt";
		
		try (BufferedReader br = new BufferedReader(new FileReader(fiName));
			 PrintWriter pw = new PrintWriter(new FileWriter(foName))) {
			
			 String line;
	            // Write table header to output file
	            pw.printf("%-15s %-15s %-5s%n", "Matric_Number", "Total_Score", "Grade");
	            pw.println("----------------------------------------");

	            while ((line = br.readLine()) != null) {
	                // Skip empty lines
	                if (line.trim().isEmpty()) continue;

	                String[] tokens = line.split("\\s+");
	                if (tokens.length < 6) {
	                    System.out.println("Skipping invalid line (incomplete data): " + line);
	                    continue;
	                }

	                try {
	                    String matricNum = tokens[0];
	                    
	                    // Parse scores and calculate totals
	                    double test1 = Double.parseDouble(tokens[1]) * 0.15;
	                    double labTest = Double.parseDouble(tokens[2]) * 0.20;
	                    double quiz = Double.parseDouble(tokens[3]) * 0.15;
	                    double project = Double.parseDouble(tokens[4]) * 0.10;
	                    double finalExam = Double.parseDouble(tokens[5]) * 0.40;

	                    double totalScore = test1 + labTest + quiz + project + finalExam;
	                    String grade = getUPMGrade(totalScore);

	                    // Write to output file
	                    pw.printf("%-15s %-15.2f %-5s%n", matricNum, totalScore, grade);

	                } 
	                catch (NumberFormatException e) {
	                    System.out.println("NumberFormatException: Found non-numeric data in line [" + line + "]. Skipped.");
	                }
	            }

	            System.out.println("Processing completed. Results saved to " + foName);

	        } 
		    catch (IOException e) {
	            System.out.println("IOException: Error opening/reading/writing files: " + e.getMessage());
		    }
	        }
		
	    //Decide the grade for each students
		public static String getUPMGrade(double score) {
		    if (score >= 80 && score <= 100) return "A";
		    else if (score >= 75) return "A-";
		    else if (score >= 70) return "B+";
		    else if (score >= 65) return "B";
		    else if (score >= 60) return "B-";
		    else if (score >= 55) return "C+";
		    else if (score >= 50) return "C";
		    else if (score >= 47) return "C-";
		    else if (score >= 44) return "D+";
		    else if (score >= 40) return "D";
		    else return "F";
	    }
}

