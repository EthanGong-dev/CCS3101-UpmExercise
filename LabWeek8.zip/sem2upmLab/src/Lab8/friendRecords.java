package Lab8;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class friendRecords {
    public static void main(String[] args) {
    	String fileName = "friends.txt";
        Scanner input = new Scanner(System.in);
        
        //Write to file
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) { //create new file here
            System.out.print("Enter the number of friends you want to add: ");
            int numFriends = input.nextInt();
            input.nextLine();

            if (numFriends <= 0) {
                throw new IllegalArgumentException("Number of friends must be greater than zero.");
            }

            for (int i = 0; i < numFriends; i++) {
                System.out.println("\nFriend #" + (i + 1));
                System.out.print("Enter name: ");
                String name = input.nextLine().trim();
                
                if (name.isEmpty()) {
                    throw new IllegalArgumentException("Name cannot be empty.");
                }

                System.out.print("Enter phone number: ");
                String phone = input.nextLine().trim();
                
                if (phone.isEmpty()) {
                    throw new IllegalArgumentException("Phone number cannot be empty.");
                }

                // Save data in "Name,Phone" format
                writer.println(name + "," + phone);
            }
            
            System.out.println("\nData successfully saved to " + fileName);

        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input type. Please enter a valid number.");
            input.nextLine(); // Clear scanner buffer
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException occurred while writing to file: " + e.getMessage());
        }
        
        //Read from file and search
        System.out.print("\n--- Search Record ---\nEnter a name keyword to search: ");
        String searchKeyword = input.nextLine().trim().toLowerCase();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean found = false;
            System.out.println("\nSearch Results:");

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 2) {
                    String name = data[0];
                    String phone = data[1];

                    if (name.toLowerCase().equals(searchKeyword)) {
                        System.out.println("Name: " + name + " | Phone: " + phone);
                        found = true;
                    }
                }
            }

            if (!found) {
                System.out.println("No matching record found for " + searchKeyword);
            }

        } catch (IOException e) {
            System.out.println("IOException occurred while reading from file: " + e.getMessage());
        }
        
        input.close();
    }
}
