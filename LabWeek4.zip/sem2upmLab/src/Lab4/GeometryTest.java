package Lab4;

public class GeometryTest {
	public static void main(String[] args) {
		
		//initialize
	    double[][] data = {
	          {0, 0, 5, 10},
	          {2, 3, 7.5, 15},
	          {10, 10, 2, 5},
	          {-1, -5, 4, 12}
	    };

	   //loop
	   for (int i = 0; i < data.length; i++) {
	         Circle ci = new Circle(data[i][0], data[i][1], data[i][2]);
	         Cylinder cl = new Cylinder(data[i][0], data[i][1], data[i][2], data[i][3]);
	            
	         System.out.println("Dataset " + (i+1) + ":");
	         System.out.printf("Circle Area: %.2f\n", ci.area());
	         System.out.printf("Cylinder Surface Area: %.2f\n", cl.area());
	         System.out.println("---------------------------");
	   }
	   
	    Point p1 = new Point(0, 0);  
	    Point p2 = new Point(3, 4);   

	    double jarak = p1.distance(p2);

	    System.out.println("{ Test Distance }");
	    System.out.println("Point 1: (0,0)");
	    System.out.println("Point 2: (3,4)");
	    System.out.printf("Distance between two points: %.2f\n", jarak);
	    System.out.println("---------------------");
	
     }
}