package Lab4;

public class EmployeeTest {
    public static void main(String[] args) {
        
        //ProductionWorker objects
        ProductionWorker worker = new ProductionWorker("Ahmad Fakri", "123-A", "01-01-2023", 1, 25.0);
        
        System.out.println("{ Production Worker Details }");
        System.out.println("Name: " + worker.getName());
        System.out.println("Employee Number: " + worker.getEmployeeNumber());
        System.out.println("Hire Date: " + worker.getHireDate());
        System.out.println("Shift: " + (worker.getShift() == 1 ? "Day" : "Night"));
        System.out.printf("Hourly Pay: RM%.2f\n", worker.getHourlyPayRate());

        System.out.println("\n---------------------------------\n");

        //ShiftSupervisor objects
        ShiftSupervisor supervisor = new ShiftSupervisor("Puan Zaiton", "999-M", "15-05-2020", 75000.0, 8000.0);
        
        System.out.println("{ Shift Supervisor Details }");
        System.out.println("Name: " + supervisor.getName());
        System.out.println("Employee Number: " + supervisor.getEmployeeNumber());
        System.out.println("Annual Salary: RM" + supervisor.getAnnualSalary());
        System.out.println("Annual Bonus: RM" + supervisor.getAnnualBonus());
        System.out.printf("Total Yearly Income: RM%.2f\n", (supervisor.getAnnualSalary() + supervisor.getAnnualBonus()));
    }
}
