package Lab4;

class Cylinder extends Circle {
	
    double length;

    //Constructors
    public Cylinder(double x, double y, double radius, double length) {
        super(x, y, radius);
        this.length = length;
    }

    @Override
    public double area() {
        return 2 * Math.PI * radius * (length + radius);
    }
}
