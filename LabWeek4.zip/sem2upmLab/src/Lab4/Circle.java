package Lab4;

class Circle extends Point {
	
    double radius;

    //Constructors
    public Circle(double x, double y, double radius) {
        super(x, y);
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
}
