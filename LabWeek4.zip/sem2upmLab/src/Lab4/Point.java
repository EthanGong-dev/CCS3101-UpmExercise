package Lab4;

public class Point {
	
	    double x, y;

	    //Constructors
	    public Point(double x, double y) {
	        this.x = x;
	        this.y = y;
	    }

	    public double area() {
	        return 0;
	    }

	    public double distance(Point diff) {
	        return Math.sqrt(Math.pow(diff.x - this.x, 2) + Math.pow(diff.y - this.y, 2));
	    }
	}


