package Lab4;

class ProductionWorker extends Employee {
	
    private int shift;
    private double hourlyPayRate;

     //Constructors
    public ProductionWorker(String name, String num, String date, int shift, double rate) {
        super(name, num, date);
        this.shift = shift;
        this.hourlyPayRate = rate;
    }

    public int getShift() {
    	return shift; 
    }
    
    public void setShift(int shift) {
    	this.shift = shift; 
    
    }
    
    public double getHourlyPayRate() {
    	return hourlyPayRate; 
    }
    
    public void setHourlyPayRate(double rate) {
    	this.hourlyPayRate = rate; 
    }
}

