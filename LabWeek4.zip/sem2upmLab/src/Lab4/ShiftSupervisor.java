package Lab4;

class ShiftSupervisor extends Employee {
	
    private double annualSalary;
    private double annualBonus;

    //Constructors
    public ShiftSupervisor(String name, String num, String date, double salary, double bonus) {
        super(name, num, date);
        this.annualSalary = salary;
        this.annualBonus = bonus;
    }

    public double getAnnualSalary() {
    	return annualSalary; 
    }
    
    public void setAnnualSalary(double salary) {
    	this.annualSalary = salary; 
    }
    
    public double getAnnualBonus() {
    	return annualBonus; 
    }
    
    public void setAnnualBonus(double bonus) {
    	this.annualBonus = bonus; 
    }
}
