package Lab4;

class Employee {
	
    private String name;
    private String employeeNumber;
    private String hireDate;

    //Constructors
    public Employee(String name, String employeeNumber, String hireDate) {
        this.name = name;
        this.employeeNumber = employeeNumber;
        this.hireDate = hireDate;
    }

    public String getName() {
    	return name; 
    }
    
    public String getEmployeeNumber() { 
    	return employeeNumber; 
    }
    
    public String getHireDate() {
    	return hireDate; 
    }

    public void setName(String name) {
    	this.name = name; 
    
    }
    public void setEmployeeNumber(String num) {
    	this.employeeNumber = num; 
    
    }
    public void setHireDate(String date) {
    	this.hireDate = date; 
    }
}
