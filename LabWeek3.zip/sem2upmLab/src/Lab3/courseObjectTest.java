package Lab3;

public class courseObjectTest {

	public static void main(String[] args) {
		Course c1 = new Course("Software Engineering");
		c1.addStudent("Marcel");
		c1.addStudent("Atlas");
		c1.addStudent("Suyou");
		
		c1.dropStudent("Atlas");
		
		System.out.println("This is the list names that are in " + c1.getCourseName() + ":");
		String[] students = c1.getStudents();
        for (int i = 0; i < c1.getNumberOfStudents(); i++) {
            System.out.println((i + 1) + ". " + students[i]);
        }
	}

}
