package Lab3;

public class Order {
	private int orderNo;
	private Customer cust;
	
	Order(int orderNo) {
		this.orderNo = orderNo;
	}
	
	Order(int orderNo, Customer cust) {
		this.orderNo = orderNo;
		this.cust = cust;
	}
	
	public int getOrderNo() {
		return orderNo;
	}
	
	public void setOrderN(int orderNo) {
		this.orderNo = orderNo;
	}
	
	public Customer getCust() {
		return cust;
	}
}
