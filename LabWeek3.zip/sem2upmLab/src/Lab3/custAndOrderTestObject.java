package Lab3;

public class custAndOrderTestObject {

	public static void main(String[] args) {
		
		Order order1 = new Order(101);
		Order order2 = new Order(102);
		
		Customer cust1 = new Customer(25, "Hayabusa", order1); //i
		Customer cust2 = new Customer(67, "Ling", order2); //i
		
		order1 = new Order (101, cust1); //ii
		order2 = new Order (102, cust2); //ii
		
		cust1.setId(55); //iii
		cust1.setName("Marcel"); //iii
		order1.setOrderN(103); //iii
		
		System.out.println("Name: " + cust1.getname() + "\nId: " + cust1.getId() + "\nOrder No: " + order1.getOrderNo()); //iv
		System.out.println(); //iv
		System.out.println("Name: " + cust2.getname() + "\nId: " + cust2.getId() + "\nOrder No: " + order2.getOrderNo()); //iv
	}

}
