package Lab3;

public class Course {

	private String courseName; //default is null.
    private String[] students = new String[100];
    private int numberOfStudents; //default is 0.

    public Course(String courseName) {
        this.courseName = courseName; //set course name.
    }

    public void addStudent(String student) {
    	 if (numberOfStudents >= students.length) { //if total students is more than 100;
    	        String[] temp = new String[students.length * 2];
    	        for (int i = 0; i < students.length; i++) {
    	            temp[i] = students[i];
    	        }
    	        students = temp;
    	    }
    	 
        students[numberOfStudents] = student;
        numberOfStudents++;
    }

    public String[] getStudents() {	 //revise the method to print all the students name
    	String[] allStudents = new String[numberOfStudents];
    	for (int i = 0; i < numberOfStudents; i++) {
    		allStudents[i] = students[i];
    	}
    	
        return allStudents;
    }

    public int getNumberOfStudents() {
        return numberOfStudents;
    }

    public String getCourseName() {
        return courseName;
    }

    public void dropStudent(String student) {
    	for (int i = 0; i < numberOfStudents; i++) {
            if (students[i].equalsIgnoreCase(student)) {
                for (int j = i; j < numberOfStudents - 1; j++) {
                    students[j] = students[j + 1];
                }
                students[numberOfStudents - 1] = null;
                numberOfStudents--;
                return;
            }
        }
    }
    
    public void clear() {
    	students = new String[100];
    	numberOfStudents = 0;

    }

}
