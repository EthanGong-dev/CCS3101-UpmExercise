package Lab3;

public class Customer {
	private int id;
	private String name;
	private Order order;
	
	Customer(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	Customer(int id, String name, Order order) {
		this.id = id;
		this.name = name;
		this.order = order;
	}
	
	public int getId() {
		return id;
	}
	
	public String getname() {
		return name;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Order getOrder() { 
		return order;
	}
}
