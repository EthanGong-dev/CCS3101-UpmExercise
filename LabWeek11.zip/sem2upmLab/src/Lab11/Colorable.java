package Lab11;

interface Colorable {
	 void howToColor();
}
