package Lab11;

abstract class GeometricObject {
	 protected GeometricObject() {}
	 public abstract double getArea();
}

