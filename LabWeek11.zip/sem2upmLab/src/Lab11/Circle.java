package Lab11;

//Base Circle Class
class Circle extends GeometricObject implements Comparable<Circle> {
 private double radius;

 public Circle() {
     this.radius = 1.0;
 }

 public Circle(double radius) {
     this.radius = radius;
 }

 public double getRadius() {
     return radius;
 }

 public void setRadius(double radius) {
     this.radius = radius;
 }

@Override
public double getArea() {
    return Math.PI * radius * radius;
}

@Override
public boolean equals(Object obj) {
    if (obj instanceof Circle) {
        return this.radius == ((Circle) obj).radius;
    }
    return false;
}

@Override
public int compareTo(Circle o) {
    if (this.radius > o.radius) {
        return 1;
    } else if (this.radius < o.radius) {
        return -1;
    } else {
        return 0;
    }
}
}

