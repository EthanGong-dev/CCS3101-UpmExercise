package Lab11;

class Square extends GeometricObject implements Colorable {
    private double side;

    public Square() {
          this.side = 0;
    }

 public Square(double side) {
     this.side = side;
 }

 public double getSide() {
     return side;
 }

 public void setSide(double side) {
     this.side = side;
 }

 @Override
 public double getArea() {
     return side * side;
 }

 @Override
 public void howToColor() {
         System.out.println("Color all four sides.");
     }
}
class SimpleCircle extends GeometricObject {
	
    private double radius;
    
    public SimpleCircle(double radius) {
    	this.radius = radius; 
    }
    
    @Override 
    public double getArea() {
    	return Math.PI * radius * radius; 
    }
}

