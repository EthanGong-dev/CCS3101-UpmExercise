package Lab11;

public class TestColorable {
	 public static void main(String[] args) {
	     GeometricObject[] objects = new GeometricObject[5];
	     objects[0] = new Square(4.5);
	     objects[1] = new SimpleCircle(3.0);
	     objects[2] = new Square(10.0);
	     objects[3] = new SimpleCircle(2.0);
	     objects[4] = new Square(1.2);

	     for (int i = 0; i < objects.length; i++) {
	         System.out.println("Object [" + i + "] Area: " + objects[i].getArea());
	         if (objects[i] instanceof Colorable) {
	             ((Colorable) objects[i]).howToColor();
	         }
	     }
	 }
}