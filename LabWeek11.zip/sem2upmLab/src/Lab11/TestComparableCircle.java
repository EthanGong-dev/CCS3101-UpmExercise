package Lab11;

public class TestComparableCircle {
	 public static void main(String[] args) {
		 
	     ComparableCircle circle1 = new ComparableCircle(5.0);
	     ComparableCircle circle2 = new ComparableCircle(7.5);

	     // Comparing two instances of ComparableCircle
	     if (circle1.compareTo(circle2) > 0) {
	         System.out.println("The larger circle has a radius of: " + circle1.getRadius());
	     } else if (circle1.compareTo(circle2) < 0) {
	         System.out.println("The larger circle has a radius of: " + circle2.getRadius());
	     } else {
	         System.out.println("Both circles have the same area.");
	     }

	     // Comparing between a circle and a rectangle based on area
	     Rectangle rectangle = new Rectangle(4.0, 10.0);
	     System.out.println("\nCircle area: " + circle1.getArea());
	     System.out.println("Rectangle area: " + rectangle.getArea());
	     
	     if (circle1.getArea() > rectangle.getArea()) {
	         System.out.println("The circle is larger than the rectangle.");
	     } else if (circle1.getArea() < rectangle.getArea()) {
	         System.out.println("The rectangle is larger than the circle.");
	     } else {
	         System.out.println("Both shapes have equal areas.");
	     }
	 }
}